package com.example.ggj_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GgjBeApplicationTests {

    @Test
    void contextLoads() {
    }

}
