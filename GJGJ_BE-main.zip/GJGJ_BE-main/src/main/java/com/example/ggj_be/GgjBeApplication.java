package com.example.ggj_be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GgjBeApplication {

    public static void main(String[] args) {
        SpringApplication.run(GgjBeApplication.class, args);
    }

}
